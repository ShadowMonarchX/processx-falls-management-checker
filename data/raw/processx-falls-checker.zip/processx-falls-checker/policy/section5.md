# Falls Management Policy — Section 5 (Documentation Requirements)

REPLACE THIS FILE with the actual text of Section 5 from
`Falls_Management_Policy_ProcessX.docx`.

Paste it in plain language, requirement by requirement, e.g.:

- Every shift note must record whether the resident's fall risk
  assessment was reviewed in the last 24 hours.
- ...

Why a separate file instead of hardcoding it in a prompt string:
1. You'll want to tweak wording while testing against John Doe / Peter
   Parker without touching code.
2. It keeps the "what the policy requires" content separate from "how
   we ask the model to check it" (that logic lives in src/checker.js).
3. It's the one artifact you can point to in the interview and say
   "this is a 1:1 copy of Section 5" — useful when they ask how you
   structured the policy as input to the AI.
