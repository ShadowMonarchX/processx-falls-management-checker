import xlsx from "xlsx";

/**
 * Reads a named sheet from an xlsx file as an array of row objects.
 * Column headers become object keys, e.g. { Day: 1, Note: "..." }.
 *
 * NOTE: confirm the real header names once you open Sample_Input_Output.xlsx
 * — adjust the keys used in index.js to match exactly (case-sensitive).
 */
export function readInputSheet(filePath, sheetName) {
  const workbook = xlsx.readFile(filePath);
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) {
    const available = workbook.SheetNames.join(", ");
    throw new Error(
      `Sheet "${sheetName}" not found. Available sheets: ${available}`
    );
  }
  return xlsx.utils.sheet_to_json(sheet, { defval: "" });
}

/**
 * Writes an array of row objects into a named sheet, replacing it if it
 * already exists (so the pre-formatted Output sheets in Your_Output_File.xlsx
 * get overwritten with real flags) and saves the file in place.
 */
export function writeOutputSheet(filePath, sheetName, rows) {
  const workbook = xlsx.readFile(filePath);
  const newSheet = xlsx.utils.json_to_sheet(rows);
  workbook.Sheets[sheetName] = newSheet;
  if (!workbook.SheetNames.includes(sheetName)) {
    workbook.SheetNames.push(sheetName);
  }
  xlsx.writeFile(workbook, filePath);
}

/** Quick utility to print a sheet's rows so you can confirm real column names. */
export function inspectSheet(filePath, sheetName) {
  const rows = readInputSheet(filePath, sheetName);
  console.log(JSON.stringify(rows, null, 2));
}
