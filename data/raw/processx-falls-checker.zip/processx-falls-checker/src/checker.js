import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SYSTEM_PROMPT = `You are a documentation compliance checker for a nursing home's
Falls Management Policy. You are given the policy's documentation
requirements and a single day's nurse progress note. Your only job is
to check the note against the requirements — do not assess clinical
judgment, only whether the note documents what the policy requires.

Rules:
- Flag a requirement as an issue if it is missing entirely, or present
  but too vague/generic to count as meeting the requirement (e.g. "pt
  monitored" with no specifics when the policy requires a specific
  frequency or observation).
- Do not flag anything not actually required by the policy text given.
- Each flag must name the specific requirement and say exactly what is
  missing or vague, in language a nurse could act on directly.
- Respond with ONLY valid JSON, no markdown fences, no preamble.`;

function buildUserPrompt(policyText, day, noteText) {
  return `POLICY — DOCUMENTATION REQUIREMENTS (Section 5):
${policyText}

NURSE'S PROGRESS NOTE — DAY ${day}:
${noteText}

Check the note against every requirement above. Respond with this exact JSON shape:
{
  "flags": [
    { "requirement": "short name of the requirement", "issue": "specific, actionable description of what's missing or vague" }
  ]
}
If every requirement is fully and specifically met, respond with { "flags": [] }.`;
}

/**
 * Checks one day's note against the policy. Returns { flags: [...] }.
 */
export async function checkNote({ policyText, day, noteText }) {
  const response = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 1000,
    system: SYSTEM_PROMPT,
    messages: [{ role: "user", content: buildUserPrompt(policyText, day, noteText) }],
  });

  const text = response.content
    .map((block) => (block.type === "text" ? block.text : ""))
    .join("\n")
    .trim();

  const cleaned = text.replace(/^```json\s*|```$/g, "").trim();

  try {
    return JSON.parse(cleaned);
  } catch (err) {
    throw new Error(`Model did not return valid JSON for Day ${day}:\n${text}`);
  }
}
