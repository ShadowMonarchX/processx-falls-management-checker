import "dotenv/config";
import fs from "fs";
import { readInputSheet, writeOutputSheet, inspectSheet } from "./excelIO.js";
import { checkNote } from "./checker.js";

const POLICY_PATH = new URL("../policy/section5.md", import.meta.url);
const POLICY_TEXT = fs.readFileSync(POLICY_PATH, "utf-8");

async function run(filePath, residentName) {
  const inputSheetName = `${residentName} - Input`;
  const outputSheetName = `${residentName} - Output`;

  const rows = readInputSheet(filePath, inputSheetName);
  const outputRows = [];

  for (const row of rows) {
    // TODO: confirm these keys match the real headers (run --inspect first)
    const day = row.Day ?? row.day ?? row["Day #"];
    const noteText = row.Note ?? row["Progress Note"] ?? row.note ?? "";

    console.log(`Checking Day ${day}...`);
    const result = await checkNote({ policyText: POLICY_TEXT, day, noteText });

    if (result.flags.length === 0) {
      outputRows.push({ Day: day, Flag: "No issues found", Detail: "" });
    } else {
      for (const flag of result.flags) {
        outputRows.push({ Day: day, Flag: flag.requirement, Detail: flag.issue });
      }
    }
  }

  writeOutputSheet(filePath, outputSheetName, outputRows);
  console.log(`Done — wrote ${outputRows.length} row(s) to "${outputSheetName}" in ${filePath}`);
}

const args = process.argv.slice(2);

if (args[0] === "--inspect") {
  const [, filePath, sheetName] = args;
  if (!filePath || !sheetName) {
    console.log('Usage: npm run dev -- --inspect "<file.xlsx>" "<Sheet Name>"');
    process.exit(1);
  }
  inspectSheet(filePath, sheetName);
} else {
  const [filePath, residentName] = args;
  if (!filePath || !residentName) {
    console.log('Usage: npm run dev -- "<file.xlsx>" "<Resident Name>"');
    console.log('e.g.:  npm run dev -- "data/Sample_Input_Output.xlsx" "Peter Parker"');
    process.exit(1);
  }
  run(filePath, residentName).catch((err) => {
    console.error(err.message);
    process.exit(1);
  });
}
