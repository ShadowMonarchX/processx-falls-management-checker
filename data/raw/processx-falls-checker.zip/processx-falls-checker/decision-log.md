# Decision Log

## How I structured the policy as input to the AI
-

## One thing the AI suggested that I changed or rejected, and why
-

## One decision the AI could not make for me, and how I resolved it
-
