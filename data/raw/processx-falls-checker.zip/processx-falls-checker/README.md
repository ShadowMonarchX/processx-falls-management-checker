# ProcessX Falls Documentation Checker

Reads a nurse's daily progress note from an Excel input sheet, checks it
against Section 5 (Documentation Requirements) of the Falls Management
Policy using Claude, and writes specific, actionable flags into the
matching Excel output sheet.

## Setup

1. `npm install`
2. Copy `.env.example` to `.env` and add your `ANTHROPIC_API_KEY`
3. Open `Falls_Management_Policy_ProcessX.docx`, copy Section 5's actual
   requirements into `policy/section5.md` (replacing the placeholder)
4. Drop your working xlsx file into `data/` (e.g. `Sample_Input_Output.xlsx`)

## Usage

Check the real column headers first (input sheets may not be named
exactly "Day" / "Note"):

```
npm run dev -- --inspect "data/Sample_Input_Output.xlsx" "Peter Parker - Input"
```

Then run the checker for a resident — this reads `"<Name> - Input"` and
writes/overwrites `"<Name> - Output"` in the same file:

```
npm run dev -- "data/Sample_Input_Output.xlsx" "Peter Parker"
```

Validate against the sample pair first:
- `"John Doe"` → output should come back with `"No issues found"` for all 3 days
- `"Peter Parker"` → output should match the flags in the provided expected sheet

Once those two match, run it against each resident in `Your_Output_File.xlsx`.

## How it works

`src/index.js` reads each day's row from the input sheet, passes the note
text plus the policy text to `src/checker.js`, and writes the returned
flags to the output sheet via `src/excelIO.js`. The policy lives in its
own file (`policy/section5.md`) rather than being hardcoded into a prompt
string, so it can be edited and re-tested without touching code, and so
the "what's required" content stays separate from "how we ask the model
to evaluate it" (the prompt logic in `checker.js`).

Each requirement check returns either an empty flag list (fully compliant)
or a list of `{ requirement, issue }` objects, where `issue` is written to
be directly actionable by a nurse, not a generic "missing information."

## Project structure

```
processx-falls-checker/
├── policy/section5.md   — the policy's documentation requirements (source of truth)
├── src/
│   ├── index.js          — CLI entry point, orchestrates the run
│   ├── checker.js         — builds the prompt, calls Claude, parses flags
│   └── excelIO.js         — reads input sheets, writes output sheets
├── data/                  — put your xlsx files here (gitignored)
└── decision-log.md
```
